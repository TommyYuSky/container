#! /bin/sh

set -x
autoreconf -ifv -I config
